from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 6
q6_df = rating_df.groupBy('movieId').count()
q6_df = q6_df.join(movie_df.select('movieId','title'),['movieId']).orderBy(q6_df['count'].desc())
q6_df.select(col('title'),col('count')).show()