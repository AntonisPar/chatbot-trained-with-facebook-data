from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 10
q10_df = rating_df.join(tag_df, ['movieId'], 'inner')
q10_df = q10_df.select("movieId","tag").where((col('tag') == "funny") & (col('rating') > 3.5)).dropDuplicates()
q10_df = q10_df.join(movie_df, ['movieId'], 'inner')
q10_df = q10_df.withColumn("genre",explode(split("genres","[|]")))
q10_df = q10_df = q10_df.groupBy(q10_df['genre']).count().orderBy(q10_df['genre'].asc())
q10_df.show()
