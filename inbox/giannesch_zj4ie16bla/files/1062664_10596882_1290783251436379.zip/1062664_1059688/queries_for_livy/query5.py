from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 5
tag_df_2015 = tag_df.filter(year(tag_df['timestamp']) == 2015).select('movieId', 'tag').join(movie_df.select('movieId', 'title'), ['movieId'])
tag_df_2015 = tag_df_2015.groupBy('movieId','title').agg(concat_ws(", ", collect_list(tag_df_2015.tag)).alias('tags')).orderBy(tag_df_2015['title'].asc())
tag_df_2015.select(col('title'),col('tags')).show()
