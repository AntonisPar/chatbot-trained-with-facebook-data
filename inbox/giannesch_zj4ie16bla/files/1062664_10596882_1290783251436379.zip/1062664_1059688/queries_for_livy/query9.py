from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 9
q9_df = rating_df.withColumn('year', year(rating_df['timestamp']))
q9_df = q9_df.withColumn('doy', dayofyear(rating_df['timestamp']))
q9_df = q9_df.withColumn('hour', hour(rating_df['timestamp']))
q9_df = q9_df.groupBy(q9_df['movieId'],q9_df['year'],q9_df['doy'],q9_df['hour']).count()
q9 = q9_df.filter(q9_df['count']>1).select(sum('count'))
q9.show()
