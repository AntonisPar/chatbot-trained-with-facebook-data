from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 4
q4_df = rating_df.withColumn('year', year(rating_df['timestamp'])).groupBy('year','movieId').avg('rating') #.join(movie_df.select('movieId','title'),['movieId'])
window = Window.partitionBy(q4_df['year']).orderBy(q4_df['avg(rating)'].desc())
q4_df = q4_df.select('*', row_number().over(window).alias('row_num')).filter(col('row_num') <= 10).join(movie_df.select('movieId','title'),['movieId']).orderBy(movie_df['title'].asc()).filter(col('year') == 2005).select(col('title'))
q4_df.show()
