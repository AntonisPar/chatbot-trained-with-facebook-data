from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 3
bollywood_tag = tag_df.select('userId','movieId', lower(col('tag')).alias('tag')).filter(tag_df["tag"] == ('bollywood')).select('userId','movieId')
user_bollywood_good_rating = bollywood_tag.join(rating_df.select('userId','rating'), ["userId"], 'inner').distinct()
user_bollywood_good_rating = user_bollywood_good_rating.filter(col("rating")>3.0).dropDuplicates(['userId']).orderBy(col('userId')).select('userId')
user_bollywood_good_rating.show()
