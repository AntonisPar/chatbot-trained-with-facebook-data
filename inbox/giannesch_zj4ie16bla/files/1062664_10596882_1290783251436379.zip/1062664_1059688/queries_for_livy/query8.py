from pyspark.sql.functions import year, row_number, col, count, split, explode, rank, dayofyear, hour, sum, concat_ws, collect_list, lower
from pyspark.sql.window import Window
movie_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/movie.csv") #filename to read from
     )

rating_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/rating.csv") #filename to read from
     )

tag_df = (spark.read
      .format("csv")
      .option('header', 'true') #means that the first line contains column names
      .option("delimiter", ",") #set the delimiter to comma
      .option("inferSchema", "true") #automatically try to infer the column data types
      .load("/home/administrator/Downloads/movielens/tag.csv") #filename to read from
     )

# QUERY 8
q8_df = movie_df.withColumn('genre',explode(split('genres',"[|]")))
q8_df = q8_df.join(rating_df,['movieId'],'left')
q8_df = q8_df.groupBy('genre','title').count()
window = Window.partitionBy(q8_df['genre']).orderBy(q8_df['count'].desc())
q8_df = q8_df.select('*', row_number().over(window).alias('rank')).filter(col('rank') == 1).orderBy(col('genre').asc())
q8_df.select(col('genre'), col('title')).show()

